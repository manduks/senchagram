/**
 *
 */
Ext.define('Ext.layout.HBox', {
    extend: 'Ext.layout.FlexBox',

    alias: 'layout.hbox'
});
